import React, {Component, useState, useEffect } from "react";
import logo from './logo.svg';
import { withRouter } from "react-router-dom";
import Routes from "./routes";
import "./assets/sass/app.scss";
import './App.css';
import "./assets/css/bootstrap.min.css";

function App() {
  return (
      <Routes/>
      
  );
}

export default App;
