import React, { Component } from "react";
import { Route, BrowserRouter as Router, Switch, Redirect } from "react-router-dom";
import Home from './pages/Home/index'

function Routes() {
    return (
        <Router>
            <Route path="/" component={Home} exact />
      </Router>
    )
}
export default Routes