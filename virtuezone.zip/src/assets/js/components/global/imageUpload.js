
import { postRecord } from '../../../utils/apiRequests/postRequest'
import config from '../../../../config';


export const imageUploadService = (image, refrestoken) => {
    let formData = new FormData();
    formData.append("files", image)
    let token = refrestoken
    return postRecord(token, config.Image.uploadImage, formData).then((res) => {
           return res[0].url
    }).catch((err) => {
            return err            
    })

}

