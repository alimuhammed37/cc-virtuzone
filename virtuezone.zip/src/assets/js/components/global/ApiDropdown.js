import React from 'react';
import {getRecord} from './../../../utils/apiRequests/getRequest'
import { Form } from '../../../utils/forms';
import { connect } from 'react-redux'

class ApiDropdown extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      filteredData: [],
      value: this.props.value || this.props.multiple ? []:'',
      error: null,
      required : this.props.required ? true : false
    }

    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    this.getData(this.props.api, this.props.disableDataFetch);
  }

  componentWillReceiveProps(nextProps) {
    if (this.props.api !== nextProps.api || (!nextProps.disableDataFetch && nextProps.disableDataFetch != this.props.disableDataFetch)) {
      this.getData(nextProps.api, nextProps.disableDataFetch);
    } else if(nextProps.refetchData && nextProps.refetchData != this.props.refetchData) {
      this.getData(nextProps.api);
    }
    if (nextProps.options != null && nextProps.options != this.state.data) {
      this.setState({data: nextProps.options});
    }
    if(!nextProps.value && nextProps.value != this.props.value) {
      this.setState({value: nextProps.value});
    }

    if(nextProps.filterData && nextProps.filterData.length != this.filterLength) {
      if(nextProps.filterData){
        const {data} = this.state
        const filteredData = data.filter(d=> {
          if(Array.isArray(nextProps.filterData)) {
            return !nextProps.filterData.includes(d[nextProps.filterKey])
          }
          else return nextProps.filterData != d[nextProps.filterKey];
        });
        this.setState({filteredData});
      }
    }
  }

  getData(api, disable) {
    const splitArray = (array) => {
      const splitter = (items, splitOn) => items.reduce((prev, field)=>prev.concat(field.split(splitOn)), []);
      let newArray = splitter(splitter(array, '['), ']');
      if(newArray.length > array.length) {
        newArray = newArray.reduce((prev, field)=>field ? prev.concat(field) : prev,[]);
      }
      return newArray;
    }
    this.filterLength = 0;
    this.setState({error: null});
    if(disable) return;
    getRecord(this.props.token, api, null) .then((res)=>{
      if(res.status == 200 || res.status == 201){
        let data;
        if(this.props.dataField) {
          const fields = splitArray(this.props.dataField.split('.'));
          data = fields.reduce((prev, field)=>prev[field], res.data);
        } else {
          data = res.data.message;
        }

        if(this.props.mapData instanceof Function) {
          data = res.data.data.data.map(d=>this.props.mapData(d));
        }
        this.setState({data, filteredData: data}, ()=>{
          if(this.props.onDataFetch instanceof Function) {
            this.props.onDataFetch(this.props.optionName || this.props.name, data);
          }
        });
      }
      }).catch((res)=>{
          if (res && res.response && res.response.data && res.response.data.code == 400) {
              this.setState({error: res.response.data.message[0].message});
          }else{
              this.setState({error: 'something went wrong'});
          }
    });
  }

  handleChange(value) {
    let formattedValue;
    let formattedLabel;
    if(Array.isArray(value)) {
      formattedValue = value.map(v=>v.value);
      formattedLabel = value.map(v=>v.label);
    } else if(value) {
      formattedValue = value.value;
      formattedLabel = value.label;
    }
    this.setState({value: value});
    if (this.props.onChange instanceof Function) {
      this.props.onChange({target: {name: this.props.name, value: formattedValue, label: formattedLabel}});
    }
  }

  render() {
    return (
      <div className="form-group">
        <Form.Dropdown
          label={this.props.label}
          onChange={this.handleChange}
          placeholder={this.props.placeholder}
          {...(this.state.data.length > 0 && {defaultValue: this.props.value})}
          name={this.props.name}
          disable={this.props.disable}
          multiple={this.props.multiple}
          ReactMultiPack={this.props.ReactMultiPack}
          value={this.state.value}
          fluid
          required={this.props.required}
          search
          selection
           errorLabel       = { <label className="text-danger">{this.props.messageField} {this.props.lang && this.props.lang.is_required}</label> }
          validationErrors = {{
            requiredValue: `${this.props.messageField} is required`,
          }}
          validations = {{
            requiredValue: (values, value) => {
              if(!this.props.required) {
                return true;
              }
              if(Array.isArray(value) ? value.length === 0 : !value || !value.value) {
                return false;
              }
              return true;
            }
          }}
          options={this.state.filteredData}
        />
      </div>
    );
  }

}


const mapStateToProps = (state) => {
  return {
      lang: state.auth.lang && state.auth.lang.payload,
  };
};
export default connect(
  mapStateToProps,
  null
)(ApiDropdown)