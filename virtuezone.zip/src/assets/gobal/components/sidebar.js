import React, { Component } from 'react'
import { Redirect, Link } from 'react-router-dom'
// import { connect } from 'net';
import { connect } from "react-redux";

const links = {
    //   dashboard: {url: "/", active: false},
    users: { url: "/", active: false },
    products: { url: "/products", active: false },
    admins: { url: "/admins", active: false },
    badges: { url: "/badges", active: false },
    groups: { url: "/groups", active: false },
    application: {
        list: { url: "/sections", active: false },
        archive: { url: "/productOrder", active: false },
        active: false,
    },
    promo: { url: "/promo", active: false },
    transaction: { url: "/order-transaction", active: false }

}


class Sidebar extends React.PureComponent {
    state = {
        menuToggleEmployee: false,
        applicationActive: false,
    };

    handleMenuToggle = (name) => {
        this.setState({ menuToggleEmployee: !this.state.menuToggleEmployee });
    }


    LinkedClick(name) {
        if (name == "section") {
            this.setState({ menuToggleEmployee: true })
        }
        if (name == "productOrder") {
            this.setState({ menuToggleEmployee: true })
        }
    }


    render() {
        return (
            <React.Fragment>
                <div className="left side-menu">
                    <div className="slimScrollDiv">
                        {this.props.type == 'SUPERADMIN' ?
                            <div className="sidebar-inner slimscrollleft">
                                <div id="sidebar-menu">
                                    {/* <ul>
                                <li>
                                    <Link to={links.dashboard.url} className={`waves-effect ${window.location.pathname == "/" ? 'active' : ''}` }  ><i className="mdi mdi-briefcase"></i> <span> Dashboard </span> </Link>
                                </li>
                            </ul> */}
                                    <ul>
                                        <li>
                        <Link to={links.users.url} className={`waves-effect ${window.location.pathname == "/" || window.location.pathname.split('/')[1] == "user" || window.location.pathname == "/user/add" ? 'active' : ''}`}  ><i className="material-icons md-24">person</i> <span>{this.props.lang && this.props.lang.manage_users}</span> </Link>
                                        </li>
                                    </ul>
                                    <ul>
                                        <li>
                                            <Link to={links.admins.url} className={`waves-effect ${window.location.pathname == "/admins" || window.location.pathname.split('/')[1] == "admin" || window.location.pathname == "/admin/add" ? 'active' : ''}`}  ><i className="material-icons md-24">supervisor_account</i> <span>{this.props.lang && this.props.lang.manage_admins}</span> </Link>
                                        </li>
                                    </ul>
                                    <ul>
                                        <li>
                                            <Link to={links.groups.url} className={`waves-effect ${window.location.pathname == "/groups" || window.location.pathname.split('/')[1] == "group" || window.location.pathname == "/group/add" ? 'active' : ''}`}  ><i className="material-icons md-24">group</i> <span>{this.props.lang && this.props.lang.manage_groups}</span> </Link>
                                        </li>
                                    </ul>
                                    <ul>
                                        <li>
                                            <Link to={links.products.url} className={`waves-effect ${window.location.pathname == "/products" || window.location.pathname.split('/')[1] == "product" || window.location.pathname == "/product/add" || window.location.pathname.split('/')[1] == "lesson" || window.location.pathname.split('/')[1] == "lessons" ? 'active' : ''}`}  ><i className="material-icons md-24">category</i> <span>{this.props.lang && this.props.lang.manage_products}</span> </Link>
                                        </li>
                                    </ul>

                                    <ul>
                                        <li>
                                            <Link to={links.badges.url} className={`waves-effect ${window.location.pathname == "/badges" || window.location.pathname.split('/')[1] == "badge" || window.location.pathname == "/badge/add" ? 'active' : ''}`}  ><i className="material-icons md-24">emoji_events</i> <span>{this.props.lang && this.props.lang.manage_badges}</span> </Link>
                                        </li>
                                    </ul>


                                    <ul>
                                        <li className="has-sub">
                                            <a name="menuToggleEmployee" class={`aria-expanded = ${this.state.menuToggleEmployee ? true : false} waves-effect ${window.location.pathname == ("/productOrder") || window.location.pathname == "/sections" || window.location.pathname == "/productOrder/add" || window.location.pathname.split('/')[1] == "productOrder" ? 'active' : ''} ${this.state.menuToggleEmployee ? 'subdrop' : ''}`} onClick={this.handleMenuToggle} href="javascript:void(0)" data-toggle="collapse" data-target="#sub-emp">
                                                <i className="material-icons md-24">dashboard</i>
                                                <span>
                                                {this.props.lang && this.props.lang.applications}
                                                </span>
                                                <span class="menu-arrow"></span>
                                            </a>
                                            <ol id="sub-emp" className={`collapse sub-nav list-unstyled ${links.application.active ? 'show' : ''}`}>
                                                <li>
                                                    <Link to={links.application.list.url} className={links.application.list.active ? 'active' : ''}>
                                                        <i className="material-icons md-24">amp_stories</i>
                                                        <span>{this.props.lang && this.props.lang.sections}</span>
                                                    </Link>
                                                </li>
                                                <li>
                                                    <Link to={links.application.archive.url} className={links.application.archive.active ? 'active' : ''}>
                                                        <i className="material-icons md-24">sort</i>
                                                        <span>{this.props.lang && this.props.lang.product_orders}</span>
                                                    </Link>
                                                </li>
                                            </ol>
                                        </li>

                                    </ul>

                                    <ul>
                                        <li>
                                            <Link className={`waves-effect ${window.location.pathname == "/promo" || window.location.pathname.split('/')[1] == "promo" || window.location.pathname == "/promo/add" ? 'active' : ''}`} to={links.promo.url}><i className="material-icons md-24">local_offer</i> <span>{this.props.lang && this.props.lang.manage_promo} </span> </Link>
                                        </li>
                                    </ul>

                                    <ul>
                                        <li>
                                            <Link className={`waves-effect ${window.location.pathname == "/order-transaction" || window.location.pathname.split('/')[1] == "order-transaction" || window.location.pathname == "/order-transaction/add" ? 'active' : ''}`} to={links.transaction.url}><i className="material-icons md-24">payment</i> <span>{this.props.lang && this.props.lang.order_transaction}</span> </Link>
                                        </li>
                                    </ul>


                                </div>
                            </div>
                            :
                            <div className="sidebar-inner slimscrollleft">
                                <div id="sidebar-menu">

                                    <ul>
                                        <li>
                        <Link to={links.users.url} className={`waves-effect ${window.location.pathname == "/" || window.location.pathname == "/user/edit" || window.location.pathname == "/user/add" ? 'active' : ''}`}  ><i className="material-icons md-24">person</i> <span>{this.props.lang && this.props.lang.manage_users}</span> </Link>
                                        </li>
                                    </ul>
                                    <ul>
                                        <li>
                                            <Link to={links.application.archive.url} className={links.application.archive.active ? 'active' : ''}>
                                                <i class="material-icons md-24">amp_stories</i>
                                                <span>{this.props.lang && this.props.lang.product_orders}</span>
                                            </Link>
                                        </li>
                                    </ul>
                                </div>
                            </div>

                        }
                    </div>
                </div>
                }
            </React.Fragment>

        )
    }
}

const mapStateToProps = (state) => {
    return {
        lang: state.auth.lang && state.auth.lang.payload,
        type: state.me.UserType
    }
}

export default connect(mapStateToProps, null)(Sidebar)