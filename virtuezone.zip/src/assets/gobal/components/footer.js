import React, { Component } from 'react'
import { connect } from 'react-redux'

class Footer extends Component {
    render () {

      return (
      <footer className="footer">Copyright © { new Date().getFullYear() } Emotika. {this.props.lang && this.props.lang.copy_right}</footer>
      )
  }
}


const mapStateToProps = (state) => {
  return {
      lang: state.auth.lang.payload,
  };
};
export default connect(
  mapStateToProps,
  null
)(Footer)
