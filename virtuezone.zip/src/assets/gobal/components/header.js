import React, { Component } from 'react'
import { Token, lang } from './../../utils/redux/auth/action'
import { Me } from './../../utils/redux/me/action'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Link } from 'react-router-dom'
import { Form } from '../../utils/forms';
import $ from "jquery"
import { Auth } from "aws-amplify";
import language from './../../utils/language/language'

class Header extends Component {

    constructor(props) {
        super(props);
        this.state = {
            user: null,
            isMenuOpen: true,
            first_name: '',
            last_name: '',
            email: '',
            currentSelected: " EN",
            profile: " Profile",
            logout: " Logout"
        }
        this.logout = this.logout.bind(this);
        this.changeLang = this.changeLang.bind(this);
    }

    onHamburgerClick = () => {
        const { isMenuOpen } = this.state;
        if (isMenuOpen) {
            $('#wrapper').addClass('enlarged');
            $('#wrapper').addClass('forced');
        } else {
            $('#wrapper').removeClass('enlarged');
        }
        this.setState({ isMenuOpen: !isMenuOpen });
    }

    logout() {
        this.props.Token(null);
        this.props.history.push("/login");

    }

    async componentDidMount() {      
        try {
            const user = await Auth.currentAuthenticatedUser()
            this.setState({
                first_name: user.attributes.name,
                last_name: user.attributes.given_name,
                image: user.attributes.picture,

            })
        }
        catch (e) {
            console.log(e)
        }
    }
    static getDerivedStateFromProps(props){
          if(props.selectedLng == "en"){
            return {
                currentSelected: "EN",
                profile: " Profile",
                logout: " Logout",
            }
        }else{
            return {
                currentSelected: "LT",
                profile: " profilis",
                logout: " Atsijungti",
            }
        }
    }

    changeLang(ln){
       let lang = language(ln)
       this.props.lang(lang)
    }

    render() {
        return (
            <div className="topbar">
                <div className="topbar-left">
                    <div className="logo">
                        <span>
                            <Form.Image src="../../../images/emotika_logosidebar.svg" alt="Emotika Logo" className="company-logo" />
                        </span>
                        <p className="logo-half">
                            <Form.Image src="../../images/emotikaicon.png" alt="Emotika Logo" />
                        </p>
                    </div>
                </div>
                <div className="navbar navbar-default" role="navigation">
                    <div className="container-fluid">
                        <div className="clearfix">
                            <ul className="nav navbar-left">
                                <li>
                                    <button className="button-menu-mobile open-left waves-effect" onClick={this.onHamburgerClick}>
                                        <i className="mdi mdi-menu" ></i>
                                    </button>
                                </li>
                            </ul>



                            <ul className="nav navbar-right d-flex align-items-center">
                                <li className="dropdown user-box">
                                    <a href="" className="dropdown-toggle waves-effect user-link" data-toggle="dropdown" aria-expanded="true">
                                     <li><a href="javascript:void(0)" className="dropdown-item"><i className="material-icons md-24">language</i> { this.state.currentSelected.toUpperCase()}</a></li>
                                    </a>
                                    <ul className="dropdown-menu dropdown-menu-right arrow-dropdown-menu arrow-menu-right user-list notify-list">
                                        <li onClick={()=> this.changeLang('en')}><a href="javascript:void(0)" className="dropdown-item">EN</a></li>
                                        <li onClick={()=> this.changeLang('lt')}><a href="javascript:void(0)" className="dropdown-item">LT</a></li>
                                    </ul>
                                </li>
                            </ul>
                            

                            <ul className="nav navbar-right d-flex align-items-center">
                                <li className="dropdown user-box">
                                    <a href="" className="dropdown-toggle waves-effect user-link" data-toggle="dropdown" aria-expanded="true">
                                        <img className="rounded-circle user-img mr-2" src={this.state.image && this.state.image ? this.state.image : '/images/avatar.jpg'} />
                                        <strong>{this.state.first_name && this.state.first_name + ' ' + this.state.last_name}</strong>
                                    </a>
                                    <ul className="dropdown-menu dropdown-menu-right arrow-dropdown-menu arrow-menu-right user-list notify-list">
                                    <li><a href="/profile" className="dropdown-item"><i className="material-icons md-24">account_circle</i>{ this.state.profile}</a></li>
                                    <li onClick={this.logout}><a href="javascript:void(0)" className="dropdown-item"><i className="material-icons md-24">exit_to_app</i>{ this.state.logout}</a></li>
                                    </ul>
                                </li>
                            </ul>

                            
                        </div>
                        
                    </div>
                </div>

                
            </div>
        )
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({
        Token: Token,
        lang: lang,
        Me: Me
    }, dispatch)
};

const mapStateToProps = (state) => {
    return {
        token: state.auth.Token,
        me: state.me
    };
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Header)
