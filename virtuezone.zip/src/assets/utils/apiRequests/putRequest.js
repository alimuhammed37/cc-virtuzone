import axios from 'axios';

export const putRecord = (token, hasUrl, params) => {
  return new Promise((resolve, reject) => {
    if (navigator.onLine === true) {
      // let URL = window.APP.config.API_URL;
      // let fullURl = URL + hasUrl;
      let URL = hasUrl
      let header = [];
      if (token) {
        header = {
          Authorization: 'Bearer ' + token
        };
      } else {
        header = {
          Authorization: 'null'
        };
      }

        axios({
          method: 'PUT',
          url: URL,
          headers: {
            Authorization: header.Authorization
          },
          data: params
        })
          .then(response => {
            resolve(response.data);
          })
          .catch(error => {
            if (
              error &&
              error.response &&
              error.response.data &&
              (error.response.data.statusCode === 403 ||
                error.response.data.statusCode === 401)
            ) {
            }
            reject(error);
          })
    } else {
      reject({
        response: {
          data: {
            code: 400,
            message: [{ message: 'Internet is disconnected.' }]
          }
        }
      });
    }
  });
};
