import axios from 'axios'

export const deleteRecord = ((token, hasUrl, params)=>{
    return new Promise((resolve, reject) => {
        if(navigator.onLine === true){
            // let URL = window.APP.config.API_URL
            // let fullURl = URL + hasUrl
           let fullURl = hasUrl
            let header = []
            if(token){
                header = {
                    Authorization: 'Bearer ' + token,
                };
            }else{
                header = {
                    Authorization: 'null',
                };
            }
                axios({
                    method: 'DELETE',
                    url: fullURl,
                    // headers: {Authorization : header.Authorization},
                    data: params,
                    })
                    .then((response) => {
                        resolve(response.data)
                    })
                    .catch((error) => {
                        if((error && error.response && error.response.data)
                            && (error.response.data.statusCode === 403
                            || error.response.data.statusCode === 401) ) {
                        }
                        reject(error)
                    })
                  
        }else{
            reject({response : {'data' : {'code' : 400, 'message':[{message:'Internet is disconnected.'}] }}})
        }
    })
})
