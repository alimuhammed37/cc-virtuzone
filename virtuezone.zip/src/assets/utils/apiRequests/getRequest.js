import axios from 'axios'

const options = {
    'Access-Control-Allow-Origin': '*',
   'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE',
//    'Access-Control-Allow-Headers': 'Content-Type',
   'Content-Type': 'application/json'
};
export const getRecord = ((token, hasUrl)=>{
    return new Promise((resolve, reject) => {
        if(navigator.onLine === true){
            // let URL = window.APP.config.API_URL
            // let fullURl = URL + hasUrl
            let fullURl = hasUrl
            let header = []
            if(token){
                header = {
                    Authorization: token,
                };
            }else{
                header = {
                    Authorization: 'null',
                };
            }
                axios({
                    method: 'GET',
                    url: fullURl,
                    headers: {Authorization : header.Authorization},
                    },options)
                    .then((response) => {
                        resolve(response)
                    })
                    .catch((error) => {
                   
                        reject(error)
                    })
        } else {
            reject({response : {'data' : {'code' : 400, 'message':[{message:'Internet is disconnected.'}] }}})
        }
    })
})
