import {createStore, applyMiddleware, compose} from 'redux'
import {persistStore, persistReducer} from 'redux-persist'
import logger from 'redux-logger'
import promise from 'redux-promise-middleware'
import storage from 'redux-persist/lib/storage'
import rootReducer from './rootReducer'
import thunk from 'redux-thunk'

const enhancer = compose(
    applyMiddleware(thunk, logger )
);

const persistConfig = {
    key: 'root',
    storage
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

let store = createStore(persistedReducer, enhancer);

let persistor = persistStore(store);
export { store, persistor };

