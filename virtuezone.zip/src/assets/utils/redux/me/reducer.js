import {
    ME, USERTYPE
} from './action'

const initialState = {
    Me: null,
    acceptedTerm: false,
    UserType: '',
};

export default function reducer(state = initialState, action) {

    switch (action.type) {
        case ME:
            if (action.payload) {
                return { ...state, ...action.payload };
            }
            return null;
        case USERTYPE:
        console.log("action.payload",action.payload)
            if (action.payload) {
                return { ...state,  UserType: action.payload };
            }
            return null;
        default:
            return state
    }
}
