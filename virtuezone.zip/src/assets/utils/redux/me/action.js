export const ME = 'ME';
export const Me = (payload) => {
    return dispatch => {
            dispatch({
                type: ME,
                payload: payload
                });
    };

};

export const USERTYPE = 'USER_TYPE';
export const UserType = (payload) => {
    console.log("PPPPPPPPPPP",payload)
    return dispatch => {
            dispatch({
                type: USERTYPE,
                payload: payload
                });
    };

};