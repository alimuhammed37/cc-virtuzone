export const TOKEN = 'TOKEN';
export const Token = (payload) => {
    return dispatch => {
        dispatch({
            type: TOKEN,
            payload: {payload}
        });
    };
    
};

export const RefreshToken = 'RefreshToken';
export const Refreshtoken = (payload) => {
    return dispatch => {
        dispatch({
            type: RefreshToken,
            payload: {payload}
        });
    };
    
};
export const LANG = "LANG";
export const lang = (payload) => {
    console.log(payload,'payload###')
    return dispatch => {
     dispatch({
        type : "LANG",
        payload: {payload}
    })
}
}

export const USERNAME = 'USERNAME';
export const Username = (payload) => {
    return dispatch => {
            dispatch({
                type: USERNAME,
                payload: {payload}
           });
    };
};
