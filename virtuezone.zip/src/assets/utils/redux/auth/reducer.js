import {
    TOKEN, RefreshToken,
    LANG, USERNAME
} from './action'

const initialState = {
    Token: null,
    acceptedTerm: false,
    RefreshToken: null,
    lang: null,
    Username: null,
};

export default function reducer(state = initialState, action) {
    switch (action.type) {
        case TOKEN:
            return { ...state, Token: action.payload };
            break;
        case LANG:
            return { ...state, lang: action.payload };
        case RefreshToken:
            return { ...state, RefreshToken: action.payload };
        case USERNAME:
            return { ...state, Username: action.payload };
        default:
            return state
    }
}