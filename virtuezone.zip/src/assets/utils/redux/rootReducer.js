import { combineReducers } from 'redux'
import auth from './auth/reducer'
import me from './me/reducer'

const rootReducer = combineReducers({
    auth,
    me
});

export default rootReducer


