import React from 'react';
import {withFormsy} from 'formsy-react';
import ReactSelect, { components } from 'react-select';
import { filterSuirElementProps } from './utils';
import Tooltip from 'react-tooltip-lite';
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';
import Typography from "@material-ui/core/Typography";

function NoOptionsMessage(props) {
  console.log(props,'props')
  if (props.options.length) return null;
  return <Typography {...props.innerProps}> No options found</Typography>;
}

class Select extends  React.Component {

  state = { allowError: false };



  componentDidMount() {
    const { defaultValue, setValue, options, multiple } = this.props;
    if (Array.isArray(defaultValue) ? defaultValue.length > 0 : defaultValue) {
      this.changeDefault(defaultValue, options);
    }


  }
  componentWillReceiveProps(nextProps) {
    if (nextProps.isFormSubmitted()) this.showError();
    if ( nextProps.defaultValue &&  nextProps.options != this.props.options) {
      this.changeDefault(nextProps.defaultValue, nextProps.options);
    }
    if (nextProps.value != this.props.value) {
      this.changeDefault(nextProps.value, nextProps.options);
    }
  }

  

  changeDefault = (defaultValue, options) => {
    let value;
    if(this.props.multiple && Array.isArray(defaultValue)) {
      value = [];
      if(defaultValue.length > 0) {
        for(let i=0; i<options.length; i++) {
          if(defaultValue.indexOf(options[i].value) != -1) {
            value.push(options[i]);
          }
        }
      }
    } else {
      for(let i=0; i<options.length; i++) {
        if(options[i].value == defaultValue) {
          value = options[i];
          break;
        }
      }
    }
    this.props.setValue(value);
  }

  changeValue = (value, selectedOptions) => {
    this.props.setValue(value);
    if (this.props.onChange instanceof Function) {
      this.props.onChange(value);
    }
  }

  showError = () => this.setState({ allowError: true });

  render() {
    const components = {
      NoOptionsMessage
    };
    const MultiValueContainer = props => {
      return (
        <div className="wrapper">
          <div className="flex-spread">
            <Tooltip className="target" tipContentClassName="foo" content={<div style={{backgroundColor:'#333', color:'#fff',padding:'5px'}}>{props.data.label}</div>}>
                <components.MultiValueContainer {...props} />
            </Tooltip>
          </div>
        </div>
        );
      };
      const {
        inputAs,
        inputClassName,
      id,
      required,
      label,
      getValue,
      defaultValue,
      multiple,
      errorLabel,
      isValid,
      isPristine,
      onChange,
      onInputChange,
      // Form.Field props
      as,
      width,
      className,
      disabled,
      inline,
      passRequiredToField,
      options,
      name,
      placeholder
    } = this.props;
    
    const { allowError } = this.state;
    const error = !isPristine() && required && (Array.isArray(getValue()) ? getValue().length === 0 : !getValue() || !getValue().value)  && this.state.allowError;
    const dropdownProps = {
      ...filterSuirElementProps(this.props),
      onChange: this.changeValue,
      onBlur: this.handleBlur,
      onClose: this.handleClose,
      className: inputClassName,
      value: getValue() || defaultValue || multiple && [] || '',
      error: `${!disabled && error}`,
      id,
      required : required
    };
    const customStyles = {
      option: (provided) => ({
        ...provided,
        width: 595,
        border: '0.5px solid rgba(128, 128, 128, .1)'
      }),
    }
    return (
      <div>
        {label && <label className="text-dark mb-1"> {label} {required && <span className="text-danger">*</span>}</label>}
        {/* <ReactSelect
          ref="select"
          {...dropdownProps}
          isMulti={multiple}
          options={this.props.options}
          components={{MultiValueContainer}}
          /> */}

        {!this.props.ReactMultiPack ? <ReactSelect
          ref="select"
          {...dropdownProps}
          isMulti={multiple}
          components={components}
          onInputChange={this.props.onInputChange}
          options={this.props.options}
          isSearchable={this.props.isSearchable}
          isDisabled={this.props.disable}          
          /> :
          <div className='react-select__menu'>
          <ReactMultiSelectCheckboxes styles={customStyles} classNamePrefix="react-select" placeholderButtonLabel = {placeholder} {...dropdownProps} options={this.props.options} /> 
          </div>  
          }

        { !disabled && error && errorLabel && React.cloneElement(errorLabel) }
      </div>
    );
  }
};

export default withFormsy(Select);
