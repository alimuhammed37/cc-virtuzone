import React from 'react';

class FormsyRadioButton extends React.Component {
  render() {
    const {value, name, onChange, defaultChecked, checked, label} = this.props;
    return (
      <React.Fragment>
          <input id={this.props.id} type='radio' name={name} defaultChecked={defaultChecked} value={value} checked={checked} onChange={onChange}/>
          {label && <label htmlFor={this.props.id}>{label}</label>}
      </React.Fragment>

    );






  }
}

export default FormsyRadioButton;