import React from 'react';

class FormsyCheckBox extends React.Component {
  render() {
    const {onChange, refFunc, label, lableClass, disabled} = this.props;
    return (
      <React.Fragment>
        <div className="d-flex">
        <input style={{width:20, height:20}} className="mr-1 boxTop" id={this.props.id} ref={checkRef => {
          if (this.props.refFunc instanceof Function)
          refFunc(checkRef)
        }} type='checkbox' onChange={onChange} disabled={disabled} checked={this.props.checked}/>
        {label && <label style={{marginTop:3}} className={this.props.lableClass ? "text-primary d-blcok" : ""}>{label}</label>}
        {/* {label && <label className={this.props.lableClass ? "text-primary d-blcok" : ""} htmlFor={this.props.id}>{label}</label>} */}
        </div>
      </React.Fragment>

    );
  }
}

export default FormsyCheckBox;
