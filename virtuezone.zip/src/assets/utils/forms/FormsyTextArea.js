import { withFormsy } from 'formsy-react';
import React from 'react';
import {filterSuirElementProps} from './utils'

class FormsyTextArea extends React.Component {

  state = { allowError: false };

  componentDidMount() {
    const { defaultValue, setValue } = this.props;
    if (defaultValue) setValue(defaultValue);
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.isFormSubmitted()) this.showError();
    if(nextProps.value != this.props.getValue()) {
      this.props.setValue(nextProps.value);
    }
  }

  handleChange = (e, data) => {
    const {value} = e.target;
    this.props.setValue(value);
    if (this.props.onChange) this.props.onChange(e, data);
    if (this.props.instantValidation) this.showError();
  }

  handleBlur = (e, data) => {
    this.showError();
    if (this.props.onBlur) this.props.onBlur(e, data);
  }

  showError = () => this.setState({ allowError: true });

  render() {
    const {
      id,
      inputAs,
      inputClassName,
      required,
      label,
      defaultValue,
      getValue,
      isValid,
      isPristine,
      getErrorMessage,
      errorLabel,
      as,
      width,
      // className,
      disabled,
      inline,
      passRequiredToField,
    } = this.props;

    const { allowError } = this.state;
    const error = !isPristine() && !isValid() && allowError;

    const inputProps = {
      ...filterSuirElementProps(this.props),
      value: getValue() || isPristine() && defaultValue || '',
      onChange: this.handleChange,
      onBlur: this.handleBlur,
      className: inputClassName,
      error: `${!disabled && error}`,
      label,
      id,
    };
    delete inputProps.inputClassName;

    return (
        <div className="form-group">
        {label && <label className="text-dark mb-1"> {label} {required && <span className="text-danger">*</span>}</label>}
        <textarea {...inputProps} />
        { !disabled && error && errorLabel && React.cloneElement(errorLabel, {}, getErrorMessage()) }
        </div>
    );
  }
}

export default withFormsy(FormsyTextArea);
