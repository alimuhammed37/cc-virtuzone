import React, {ReactDOM} from 'react';


class Modal extends React.Component {

  componentWillReceiveProps(nextProps) {
    if(nextProps.closeModal != this.props.closeModal && nextProps.closeModal === false) {
      this.closeModal();
    }
  }

  closeModal = () => {
    this.inputElement.click();
    if(typeof this.props.resetForm === 'Function')
      this.props.resetForm(this.props.id);
  };

  render() {
    const {
      heading,
      body,
      id,
    } = this.props

    return (
        <div className="container">
        <div className="modal fade" ref={ref=> this.ref = ref} id={id || "myModal"} role="dialog">
          <div className={this.props.pdf ? "modal-dialog modal-xl" : "modal-dialog modal-md" } >
            <div className="modal-content">
              <div className="modal-header">
                <button ref={input => this.inputElement = input} onClick={() => this.props.onModalClose(this.props.id)} type="button" className="btn btn-default" data-dismiss="modal"><i class="close-times material-icons md-24">clear</i></button>
                <h4 className="modal-title">{heading}</h4>
              </div>
              <div className="modal-body">
                <p>{this.props.errorMsg}</p>
                {body}
              </div>
              <div className="modal-footer">
                <button ref={input => this.inputElement = input} onClick={() => this.props.onModalClose(this.props.id)} type="button" className="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Modal;
