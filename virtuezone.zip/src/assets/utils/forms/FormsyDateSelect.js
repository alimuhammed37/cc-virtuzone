import React, { Component } from 'react'

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
const moment        = require('moment');

export default class DateSelect extends Component {

    constructor(props) {
        super(props);
        this.state = {
            startDate : moment(this.props.startDate).toDate(),
            endDate : moment(this.props.endDate).toDate()
        }
        this.handleStateDate = this.handleStateDate.bind(this);
        this.handleEndDate = this.handleEndDate.bind(this)
        this.handleEndDateCoupon = this.handleEndDateCoupon.bind(this);

    }

    handleStateDate(date) {
      const name = this.props.startName || 'startDate';
        this.props.onDateChange(name, date);
      this.setState({startDate : date})
   }

    handleEndDate(date){
      const name = this.props.endName || 'endDate';
        if(date < this.state.startDate){
            this.setState({endDate : new Date()})
            this.props.onDateChange(name, new Date())
        }else{
            this.setState({endDate : date})
            this.props.onDateChange(name, date);
        }
    }

    handleEndDateCoupon(date){
      const name = this.props.endName || 'endDate';
        if(date < this.state.startDate){
            this.setState({endDate : new Date()})
            this.props.onDateChange(name, new Date())
        }else{
            this.setState({endDate : date})
            this.props.onDateChange(name, date);
        }
    }

    render () {
        const {startDate, endDate, dateFormat, timeIntervals, timeFormat, showTimeInput, timeInputLabel, maxDate ,minDate} = this.props;
        return(
            <div className="d-md-flex">
                <div className="mr-md-3 mb-2 mb-md-0 d-block d-md-inline-block">
                    <DatePicker
                        selected={startDate}
                        timeInputLabel={timeInputLabel}
                        showTimeInput={showTimeInput}
                        maxDate={maxDate}
                        minDate={minDate}
                        dateFormat={dateFormat}
                        timeIntervals={timeIntervals}
                        timeFormat={timeFormat}
                        placeholderText={this.props.startPlaceHolder ? this.props.startPlaceHolder : 'Date Range From'}
                        onChange={this.handleStateDate}
                        todayButton={"Today"}
                        className="form-control"
                    />
                </div>
                <div className="mr-md-3 mb-2 mb-md-0 d-block d-md-inline-block">
                    <DatePicker
                        selected={endDate}
                        timeInputLabel={timeInputLabel}
                        showTimeInput={showTimeInput}
                        maxDate={maxDate}
                        minDate={minDate}
                        dateFormat={dateFormat}
                        timeIntervals={timeIntervals}
                        timeFormat={timeFormat}
                        placeholderText={this.props.endPlaceHolder ? this.props.endPlaceHolder : 'Date Range To'}
                        onChange={ this.props.coupondate ? this.handleEndDateCoupon : this.handleEndDate}
                        todayButton={"Today"}
                        className="form-control"
                    />
                </div>
            </div>
        )
  }
}


