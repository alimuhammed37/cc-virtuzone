import React, { Component } from "react";

import ReactCrop from "react-image-crop";
import "react-image-crop/dist/ReactCrop.css";
import { connect } from "react-redux";

const getExtFromMime = (type) => {
    let ext = type.split('/')[1];
    if(ext === 'jpeg' ) ext = 'jpg';
    return ext;
}

class ImageCropper extends Component {
  constructor(props) {
    super(props);
    this.state = {
      src: null,
      ext: 'jpg',
      crop: {
        height: 50,
        width: 50,
        x: 0,
        y: 0
      },
      croppedImageUrl: props.src
    };
  }

  componentDidMount() {
    const {src} = this.props;
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.src !== this.props.src && !this.state.croppedImageUrl) {
      this.setState({croppedImageUrl: nextProps.src});
    }
  }

  onSelectFile = e => {
    if (e.target.files && e.target.files.length > 0) {
      const ext = e.target.files[0].name.split('.').pop();
      const supportedExtensions = ['jpg','jpeg','gif','png','bmp'];
      if(!supportedExtensions.includes(ext) && this.props.onError instanceof Function) {
        e.target.value = null;
        this.props.onError('File format not supported. Only jpg, jpeg, gif, png, bmp files are allowed');
        return
      }
      const reader = new FileReader();
      reader.addEventListener("load", () => {
        if(reader.result != this.state.src) {
          this.setState({src: reader.result, ext}, this.props.onCropComplete);
        }
      });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  onImageLoaded = (image, crop) => {
    this.imageRef = image;
    this.makeClientCrop(this.state.crop);
  };

  onCropComplete = (crop, percentCrop) => {
    this.makeClientCrop(crop);
  };

  onCropChange = (crop) => {
    this.setState({ crop });
  };

  async makeClientCrop(crop) {
    if (this.imageRef && crop.width && crop.height) {
      const {base64: croppedImageUrl, file} = await this.getCroppedImg(
        this.imageRef,
        crop,
        "newFile."+this.state.ext
      );
      this.setState({ croppedImageUrl });
      if(this.props.onCropComplete instanceof Function) {
        this.props.onCropComplete(file);
      }
    }
  }

  getCroppedImg(image, crop, fileName) {
    const canvas = document.createElement("canvas");
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    canvas.width = crop.width;
    canvas.height = crop.height;
    const ctx = canvas.getContext("2d");

    ctx.drawImage(
      image,
      crop.x * scaleX,
      crop.y * scaleY,
      crop.width * scaleX,
      crop.height * scaleY,
      0,
      0,
      crop.width,
      crop.height
    );

    return new Promise((resolve, reject) => {
      canvas.toBlob(blob => {
        if (!blob) {
          console.error("Canvas is empty");
          return;
        }
        blob.name = fileName;
        const file = new File([blob], fileName, {type: `image/${this.state.ext}`, lastModified: Date.now()});
        window.URL.revokeObjectURL(this.fileUrl);
        this.fileUrl = window.URL.createObjectURL(blob);
        resolve({base64: this.fileUrl, file});
      }, `image/${this.state.ext}`);
    });
  }

  render() {
    const { src, crop, croppedImageUrl } = this.state;
    const { showCropper } = this.props;
    return (
      <React.Fragment>
        <div>
          <button class="btn btn-xs btn-primary"><label style={{fontFamily:"sans-serif", margin:10}} for="files">{this.props.lang && this.props.lang.select_image}</label></button>
          <input id="files" style={{visibility : "hidden"}} type="file" onChange={this.onSelectFile} />
        </div>
        {src && showCropper && (
          <ReactCrop
            src={src}
            crop={crop}
            onImageLoaded={this.onImageLoaded}
            onComplete={this.onCropComplete}
            onChange={this.onCropChange}
          />
        )}
        {croppedImageUrl && (
          <div class="thumb-xl member-thumb mx-auto d-block">
            <img alt="Crop" style={{ width: "100%", height: "100%" }} src={croppedImageUrl} className="rounded-circle img-thumbnail" />
          </div>
        )}
      </React.Fragment>
    );
  }

}

const mapStateToProps = (state) => {
  return {
    lang: state.auth.lang.payload,
  };
};

export default connect(
  mapStateToProps,
  null
)(ImageCropper);
