import React from 'react';
class ResponseMessage extends React.Component {

    constructor(props) {
      super(props);
  
    }

    componentWillReceiveProps(nextProps) {
      if (nextProps.show === true && this.props.show !== nextProps) {
        if(this.timer) {
          clearTimeout(this.timer);
        }
        this.timer = setTimeout(() => {
          this.props.onHide();
        }, nextProps.time || 5000);
      }
    }

    componentWillUnmount() {
      if(this.timer) {
        clearTimeout(this.timer);
      }
    }

    formattedMessage = (message) => {
      if (Array.isArray(message)) {
        return message.map(this.formattedMessage);
      }
      if (typeof message === 'object' && message !== null) {
        return this.formattedMessage(message.message);
      }
      if(message instanceof String || typeof message === 'string' ) {
        return <div>{message}</div>
      }
      return null;
    }

    render() {
        const {message, type} = this.props;
        let className;
        switch (type) {
          case 'error':
            className = 'alert-danger';
            break;
          case 'warning':
            className = 'alert-warning';
            break;
          default:
            className = 'alert-success';
            break;
        }
        return (
          <React.Fragment>
            {this.props.show &&
            <div className={`alert ${className}`}>
              {this.formattedMessage(message)
              }
            </div>}
          </React.Fragment>
        );
    }
}

export default ResponseMessage;

