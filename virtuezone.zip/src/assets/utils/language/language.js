

let en = {
    // sidebar 
    lng: "en",
    manage_users : "Manage Users",
    manage_admins: "Manage Admins",
    manage_groups: "Manage Groups",
    manage_products: "Manage Products",
    manage_badges: "Manage Badges",
    applications: "Applications",
    sections: "Sections",
    section: "Section",
    product_orders : "Products Order",
    manage_promo : "Manage Promo",
    order_transaction: "Manage Transaction",

    // table headers and searching

    showing: "Showing",
    entires: "Entries out of",
    search_by_name: "Search By Name",
    search_by_group_name: "Search By Group Name",
    select_group: "Select Groups",
    groups: "Groups",
    products: "Products",
    name: "Name",
    email: "Email",
    group: "Group",
    status: "Status",
    action: "Action",

    group_name: "Group Name",
    group_member: "Group Members",
    admin: "Admin",
    user: "User",

    strapi_id: "Strapi Id",
    product_title: "Product Title",
    description: "Description",
    product_type: "Product Type",
    serach_by_title_description: "Search By Title Or Description",
    search_product: "Search Product",


    badge_icon: "Badge Icon",
    points: "Points",

    manage_section: "Manage Section",
    section_name: "Section Name",
    section_name_section: "Section Name",
    search_by_section_name: "Search By Section Name",
    search_by_section_name_product: "Search By Section Name",


    manage_product_order: "Manage Product Order",
    permission_type: "Permission Type",
    user_group: "Users/Groups",

    search_by_code_or_name: "Search By Code or Name",
    code: "Code",
    discount_per_amount: "Discount Percentage/Amount",
    available_count: "Available Count",
    used_count: "Used Count",
    start_date: "Date Start",
    end_date: "Date End",



    manage_order_transaction: "Manage Order Transactions",
    search_by_orderId: "Search By Order ID",
    orderId: "Order ID",
    transaction_id: "Transaction ID",
    charged_amount: "Charged Amount",
    billing_date: "Billing Date",
    billing_info: "Billing Information",
    view_detail: "View Details",


    total_purchases: "Total Purchases",
    current_progress: "Current Progress",
    total_points: "Total Points",
    user_info: "User Information",
    admin_info: "Admin Information",
    Purchase_item: "Purchased Items",
    purchase_order_tran: "Purchase Order Transaction",
    first_name: "First Name",
    last_name: "Last Name",
    email: "Email",
    leaderboard_type: "Leaderboard Type",
    assigned_group: "Assigned Group",
    current_badge: "Current Badge",
    purchased_date_time: "Purchased Date/Time",
    progress_status: "Progress Status",
    completed: "Completed",
    remaining: "Remaining",
    completedWith: "% Completed",
    remainingWith: "% Remaining",
    upload_image: "Upload Image",
    strick_string: "The fields marked with * are required.",
    select_leaderboard: "Select Leaderboard",
    all_users: "All Users",
    specific_group:"Specific Groups",
    group_info: "Group Information",
    group_name: "Group Name",
    select_admin: "Select Admin",
    select_user: "Select User",
    select_products:"Select Products",
    select_admin_search: "Select Admin (Type to search by name)",
    select_user_search: "Select User (Type to search by name)",
    edit_group: "Edit Group",

    assign_free_access: "Assign Free Access",
    all_products: "All Products",
    specific_products: "Specific Products",
    add_product: "Add Product",
    edit_product: "Edit Product",
    product_info: "Product Information",
    title: "Title",
    price: "Price",
    select_type: "Select Type",
    select_pre: "Select Prerequisite",
    none: "None",
    modules: "Modules",
    badges: "Badges",
    select_modules: "Select Modules",
    select_badges: "Select Badges",

    manage_lesson: "Manage Lessons",
    back_to_product: "Back to product",
    add_lesson: "Add Lesson",
    search_by_strapi_id_lesson_title: "Search By Strapi ID or Lesson Title",
    lesson_title: "Lesson Title",


    edit_lesson: "Edit Lesson",
    lesson_info: "Lesson Information",
    lesson_title: "Lesson Title",
    sort: "Sort",
    note: "Note",
    click_to_add_mcqs: "Add MCQ/Survey Lesson",
    click_to_add_ass: "Add Assessment Lesson",
    click_to_add_faq: "Add FAQ Lesson",
    mcqs_lesson: "MCQ Type Of Lesson",
    question_no: "Question No",
    option_no: "Option No",
    options: "Options",
    option_type: "Option Type",
    is_answer: "is answer?",
    click_to_add_more_options: "Click to add more options",
    close_mcq_lesson: "Close MCQ Type Of Lesson",
    ass_lesson: "Assessment Type Of Lesson",
    points_no: "Points No",
    enter_ranges: "Enter Ranges",
    range_from: "Range From",
    range_to: "Range To",
    click_to_add_more_ranges: "Click to add more ranges",
    close_ass_lesson: "Close Assessment Type Of Lesson",
    faq_lesson: "FAQ Type Of Lesson",
    artical: "Article",
    answer: "Answer",
    link: "Link",
    close_faq_lesson: "Close Faq Type Of Lesson",


    
    add_badge: "Add Badge",
    edit_badge: "Edit Badge",
    upload_badge_icon: "Upload Badge Icon",
    badge_info: "Badge Information",

    edit_section: "Edit Section",

    add_product_order_sorting: "Add Product Order & Sorting",
    edit_product_order_sorting: "Edit Product Order & Sorting",
    product_order_info: "Product Order Information",
    select_section: "Select Section",
    select_product_type: "Select Product Type",
    enter_position: "Enter Position",


    edit_promo: "Edit Promo",
    promo_info: "Promo Information",
    promo_code: "Promo Code",
    promo_name: "Promo Name",
    give_dis_setupFee: "Give 100% discount on setup fee",
    give_partial_dis: "Give a partial discount",
    select_dis_date: "Select Discount Date and Time",
    uses_per_promo_code: "Uses per promo code",    
    specific_groups: "Specific Groups",
    discount_type: "Discount Type",


    order_id: "Order ID",
    order_transaction_details: "Order Transaction Details",
    purchased_date: "Purchased Date",
    customer_name: "Customer Name",
    card_no: "Card Number",
    expiry_date: "Expiry Date",
    save_amount: "Save Amount",
    sub_total: "Sub Total",

    
    my_profile: "My Profile",
    super_admin: "super Admin",
    profile_info: "Profile Information",
    edit_profile:"Edit Profile",
    profile_image: "Profile Image",
    change_pass_form: "Change Password Form",
    current_pass: "Current Password",
    new_pass: "New Password",
    retype_pass: "Retype New Password",



    email_address: "Email Address",
    login: "Login",
    password: "Password",
    confirm_pass: "Confirm Password",
    forgot_pass: "Forgot Password?",
    phone: "Phone",
    send_code: "Send Code",
    back_to_login: "Back To Login",

    select_image: "Select Image",



    //validation messages

    is_required: "is required",

    first_name_required: "First Name is required",
    first_name_max_length: "First Name must be less than 250 characters",
    first_name_min_length: "First Name must be at least 1 characters",

    last_name_required: "Last Name is required",
    last_name_max_length: "Last Name must be less than 250 characters",
    last_name_min_length: "Last Name must be at least 1 characters",

    is_email: "Please provide a valid email address",
    default_email: "Email address is required",
    email_max_length: "Email address must be less than 100 characters",
    email_min_length: "Email address must be at least 3 characters",

    default_pass: "Password is required",
    pass_max: "Password must be less then 35 characters",

    group_name_required: "Group Name is required",
    group_name_max_length: "Group Name must be less than 250 characters",
    group_name_min_length: "Group Name must be at least 1 characters",

    title_required: "Title is required",
    title_max_length: "Title must be less than 250 characters",
    title_min_length: "Title must be at least 1 characters",

    price_required: "Price is required",
    price_max_length: "Price must be less than 6 characters",
    price_min_length: "Price must be at least 1 characters",
    only_number_allowed: "Only numbers are allowed",

    description_required: "Description is required",
    group_name_max_length: "Description must be less than 500 characters",
    group_name_min_length: "Description must be at least 3 characters",


    lesson_title_required: "Lesson Title is required",
    lesson_title_max_length: "Lesson Title must be less than 250 characters",
    lesson_title_min_length: "Lesson Title must be at least 1 characters",


    sort_required: "Sort required",
    sort_max_length: "Sort must be less than 3 characters",
    sort_min_length: "Sort must be at least 1 characters",


    question_required: "Question is required",
    question_max_length: "Question must be less than 250 characters",
    question_min_length: "Question must be at least 1 characters",

    answer_required: "Answer is required",
    answer_max_length: "Answer must be less than 250 characters",
    answer_min_length: "Answer must be at least 1 characters",
    
    option_required: "Option is required",
    option_max_length: "Option must be less than 250 characters",
    option_min_length: "Option must be at least 1 characters",

    name_required: "Name is required",
    name_max_length: "Name must be less than 250 characters",
    name_min_length: "Name must be at least 1 characters",

    points_required: "Points is required",
    points_max_length: "Points must be less than 6 characters",
    points_min_length: "Points must be at least 1 characters",

    from_range_required: "From is required",
    from_range_max_length: "From must be less than 6 characters",
    from_range_min_length: "From must be at least 1 characters",

    to_range_required: "To is required",
    to_max_length: "To must be less than 6 characters",
    to_min_length: "To must be at least 1 characters",

    description_required: "Description is required",
    description_max_length: "Description must be less than 500 characters",
    description_min_length: "Description must be at least 3 characters",


    section_name_required: "Section name is required",
    section_name_max_length: "Section name must be less than 250 characters",
    section_name_min_length: "Section name must be at least 1 characters",


    sorting_position_required: "Sorting position is required",
    sorting_position_max_length: "Sorting position must be less than 3 characters",
    sorting_position_min_length: "Sorting position must be at least 1 characters",

    product_required: "Product is required",

    promo_code_required: "Promo code is required",
    promo_code_max_length: "Promo code must be less than 50 characters",
    promo_code_min_length: "Promo code must be at least 3 characters",

    promo_name_required: "Promo name is required",
    promo_name_max_length: "Promo name must be less than 250 characters",
    promo_name_min_length: "Promo name must be at least 1 characters",

    promo_discount_required : "Discount is required",
    promo_discount_max_length: "Discount must be less than 7 characters",
    promo_discount_max_length_four: "Discount must be less than 4 characters",
    promo_discount_min_length: "Discount must be at least 1 characters",

    promo_users_per_coupon_required: "Uses per promo code is required",
    promo_users_per_coupon_discount_max_length: "Uses per promo code must be less than 5 characters",
    promo_users_per_coupon_discount_min_length: "Uses per promo code must be at least 1 characters",

    no_records_found: "No records found",
    copy_right: "All Rights Reserved",



    delete_user: "Are you sure you want to delete this user?",
    delete_admin: "Are you sure you want to delete this admin?",
    delete_group: "Are you sure you want to delete this group?",
    delete_product: "Are you sure you want to delete this product?",
    delete_badge: "Are you sure you want to delete this badge?",
    delete_section: "Are you sure you want to delete this section?",
    delete_product_order : "Are you sure you want to delete this product order?",
    delete_lesson: "Are your sure you want to delete this lesson?",
    delete_promo: "Are you sure you want to delete this promo?",

    profile: "Profile",
    logout: "Logout",

    pass_string: "*Minimum 8 Characters *Require numbers *Require special character *Require uppercase letters *Require lowercase letters",
    pass_default: "",
    pass_max: "Password must be between 8 to 35 characters",
    pass_min: "Password must be between 8 to 100 characters",    
    
    loading: "Loading",
    no_purchased_items: "No Purchased Items Founds",

    
    
    verification_code: "Verification Code",
    forgot_email_text: "If you do not receive the code in 5 minutes then please contact your Administrator",

    in_app_purchase: "Apple in app purchase transaction id",
    in_app_purchase_required: "Apple in app purchase transaction id is required",

    apple_in_app: "Apple In-App Purchase",

    







    // buttons

    download_csv: "Download CSV",
    add_user: "Add User",
    add_admin: "Add Admin",
    edit_admin: "Edit Admin",
    enabled: "Enabled",
    disabled: "Disabled",
    manage: "Manage User",
    add_group: "Add Group",
    free_access: "Free Access",
    add_product: "Add Product",
    add_badge: "Add Badge",
    add_section: "Add Section",
    add_product_order: "Add Product Order",
    add_promo : "Add Promo",
    edit_user: "Edit User",
    view_details: "View Details",
    back: "Back",
    save: "Save",
    update: "Update",
    confirm: "Confirm",
    cancel: "Cancel",
    ok: "OK"


}

let lt = {
    // sidebar 
    lng: "lt",
    manage_users : "Vartotojai",
    manage_admins: "Administratoriai",
    manage_groups: "Grupės",
    manage_products: "Produktai",
    manage_badges: "Ženkliukai",
    applications: "Aplikacija",
    sections: "Sekcijos",
    section: "Skyriau",
    product_orders : "Sekcijų turinys",
    manage_promo : "Produktų užsakymas",
    order_transaction: "Tvarkyti pavedimus",

 // table headers and searching

    showing: "Rodoma",
    entires: "Įrašų",
    search_by_name: "Ieškoti pagal pavadinimą",
    search_by_group_name: "Ieškoti grupėse",
    select_group: "Pasirinkti grupę",
    groups:"grupes",
    products: "Produktai",
    name : "Pavadinimas",
    email: "El. paštas",
    group: "Grupė (-ės)",
    status: "Statusas",
    action: "Veiksmai",

    group_name: "Grupės pavadinimas",
    group_member: "Grupės nariai",
    admin: "Administratorius",
    user: "Vartotojas",


    strapi_id: "„Strapi“ ID",
    product_title: "Produkto pavadinimas",
    description: "Aprašymas",
    product_type: "Produkto rūšis",
    serach_by_title_description: " Ieškoti pagal pavadinimą arba apibūdinimą",
    search_product: "Ieškoti pagal produktą",

    badge_icon: "Ženkliuko piktograma",
    points: "Taškai",

    manage_section: "Redaguoti sekcijas",
    section_name: "Sekcija",
    section_name_section: "Sekcijos pavadinimas",
    search_by_section_name: "Ieškoti pagal sekciją",
    search_by_section_name_product: "Ieškoti pagal sekciją",

    manage_product_order: "Redaguoti turinį",
    permission_type: "Leidimo rūšis",
    user_group: "Vartotojai / grupės",

    search_by_code_or_name: "Ieškoti pagal kodą arba pavadinimą",
    code: "Kodas",
    discount_per_amount: "Nuolaidos procentas / suma",
    available_count: "Leidžiamas kiekis",
    used_count: "Panaudotas kiekis",
    start_date: "Pradžios data",
    end_date: "Pabaigos data",

    manage_order_transaction: "Redaguoti užsakymus",
    search_by_orderId: "Ieškoti pagal užsakymo ID",
    orderId: "Užsakymo ID",
    transaction_id: "Transakcijos ID",
    charged_amount: "Išrašyta suma",
    billing_date: "Sąskaitos data",
    billing_info: "Sąskaitos informacija",
    view_detail: "Žiūrėti detales",


    total_purchases: "Iš viso pirkimų",
    current_progress: "Dabartinė pažanga",
    total_points: "Iš viso Taškai",
    user_info: "Vartotojo informacija",
    admin_info: "Administratoriaus informacija",
    Purchase_item: "Įsigytos prekės",
    purchase_order_tran: "Pirkimo užsakymo operacija",
    first_name: "Vardas",
    last_name: "Pavardė",
    email: "El. paštas",
    leaderboard_type: "Lyderių lentelės rūšis",
    assigned_group: "Paskirtoji grupė",
    current_badge: "Dabartinis ženkliukas",
    purchased_date_time: "Pirkimo data / laikas",
    progress_status: "Progresas",
    completed: "baigta",
    remaining: "likę",
    completedWith: "% baigta",
    remainingWith: "% likę",
    upload_image: "Įkelti nuotrauką",
    strick_string: "Laukai, pažymėti *, yra būtini.",
    select_leaderboard: "pasirinkti vartotojus",
    all_users: "Visi vartotojai",
    specific_group:"Konkrečios grupės",
    group_info: "Informacija apie grupę",
    group_name: "Grupės pavadinimas",
    select_admin: "Pasirinkite administratorių",
    select_user: "Pasirinkite vartotoją",
    select_products:"Pasirinkite produktą (-us)",
    select_admin_search: "Pasirinkite Administratorių (pradėkite rašyti, norėdami ieškoti pagal vardą)",
    select_user_search: "Pasirinkite vartotoją (pradėkite rašyti, norėdami ieškoti pagal vardą)",
    edit_group: "Redaguoti Grupės",

    assign_free_access: "Priskirkite nemokamą prieigą",
    all_products: "Visi produktai",
    specific_products: "Konkretūs produktai",
    add_product: "Pridėti produktą",
    edit_product: "Redaguoti produktą",
    product_info: "Produkto informacija",
    title: "Pavadinimas",
    price: "Kaina",
    select_type: "Pasirinkite rūšį",
    select_pre: "Produktas prieinamas vartotojams, kurie atitinka šį reikalavimą",
    none: '“Visiems”',
    modules: "Moduliai",
    badges: "Ženkliukas",
    select_modules: "Pasirinkite modulius",
    select_badges: "Pasirinkite ženkliuką",

    manage_lesson: "Redaguoti pamokas",
    back_to_product: "atgal į produktą",
    add_lesson: "Pridėti pamoką",
    search_by_strapi_id_lesson_title: "Ieškoti pagal „Strapi“ ID arba Pamokos pavadinimas",
    lesson_title: "Pamokos pavadinimas",

    edit_lesson: "Redaguoti Pamokos",
    lesson_info: "Pamokos informacija",
    lesson_title: "Pamokos pavadinimas",
    sort: "Rūšiuoti",
    note: "Užrašai",
    click_to_add_mcqs: "Pridėti MCQ/apklausos pamoką",
    click_to_add_ass: "Pridėti vertinimo pamoką",
    click_to_add_faq: "Pridėti FAQ pamoką",
    mcqs_lesson: "MCQ pamokos rūšis",
    question_no: "Klausimas Nr",
    option_no: "Pasirinkimas Nr",
    options: "Pasirinkimo",
    option_type: "Pasirinkimo rūšis",
    is_answer: "Atsakyta?",
    click_to_add_more_options: "Pridėkite daugiau funkcijų",
    close_mcq_lesson: "Uždaryti MCQ rūšies pamoką",
    ass_lesson: "Vertinimo rūšies pamoka",
    points_no: "Taškai Nr",
    enter_ranges: "Įvesti intervalus",
    range_from: "Intervalo forma",
    range_to: "Intervalas iki",
    click_to_add_more_ranges: "Pridėti daugiau intervalų",
    close_ass_lesson: "Uždaryti vertinimo tipo pamoką",
    faq_lesson: "FAQ rūšies pamoka",
    artical: "Straipsnis",
    answer: "Atsakymas",
    link: "Nuoroda",
    close_faq_lesson: "Uždaryti FAQ rūšies pamoką",

    add_badge: "Pridėti ženkliuką",
    edit_badge: "Redaguoti ženkliuką",
    upload_badge_icon: "Įkelti ženkliuko piktogramą",
    badge_info: "Informacija apie ženkliuką",

    edit_section: "Redaguoti Skyriaus",

    add_product_order_sorting: "Pridėti produkto užsakymą ir rūšiavimą",
    edit_product_order_sorting: "Redaguoti produkto užsakymą ir rūšiavimą",
    product_order_info: "Informacija apie produkto užsakymą",
    select_section: "Pasirinkite skyrių",
    select_product_type: "Pridėti produkto tipą",
    enter_position: "įveskite poziciją",


    edit_promo: 'Redaguoti "Promo"',
    promo_info: 'Informacija',
    promo_code: "Promo kodas",
    promo_name: "Pavadinimas",
    give_dis_setupFee: "Suteikti 100% nuolaidą",
    give_partial_dis: "Pritaikyti dalinę nuolaidą",
    select_dis_date: 'Nustatyti “Promo” kodo galiojimo laiką',
    uses_per_promo_code: 'Vartotojų kiekis vienam kodui', 
    specific_groups: "Konkrečios grupės",
    discount_type: "Nuolaidos tipas",

    order_id: "Užsakymo ID",
    order_transaction_details: "užsakymo operacijos duomenys",
    purchased_date: "Pirkimo data",
    customer_name: "Kliento vardas",
    card_no: "Kortelės numeris",
    expiry_date: "Galioja iki",
    save_amount: "Sutaupyta",
    sub_total: "Tarpinė suma",

    my_profile: "mano profilį",
    super_admin: "super Administratorių",
    profile_info: "profilio informacija",
    edit_profile:"Redaguoti profilį",
    profile_image: "profilio vaizdas",
    change_pass_form: "pakeisti slaptažodžio formą",
    current_pass: "Dabartinis slaptažodis",
    new_pass: "Naujas Slaptažodis",
    retype_pass: "Pakartokite naująjį slaptažodį",


    email_address: "El. pašto adresas",
    password: "Slaptažodis",
    confirm_pass: "Patvirtinti slaptažodį",
    login: "Prisijungti",
    forgot_pass: "Pamiršote slaptažodį?",
    phone: "Tel. Nr.",
    send_code: "siųsti kodą",
    back_to_login: "atgal į prisijungimą",

    select_image: "Pasirinkite vaizdą",


     //validation messages

     is_required: "yra būtinas",

     first_name_required: "Vartotojo vardas būtinas",
     first_name_max_length: "Vardas turi susidaryti iš ne daugiau kaip 250 simbolių",
     first_name_min_length: "Vardas turi susidaryti iš ne mažiau kaip 1 simbolio",
 
     last_name_required: "pavardė vardas būtinas",
     last_name_max_length: "pavardė susidaryti iš ne daugiau kaip 250 simbolių",
     last_name_min_length: "pavardė susidaryti iš ne mažiau kaip 1 simbolio",
 
     is_email: "Please provide a valid email address",
     default_email: "Reikalingas el. pašto adresas",
     email_max_length: "El. pašto adresas turi susidaryti ne daugiau kaip iš 100 simbolių",
     email_min_length: "El. pašto adresas turi susidaryti iš ne mažiau kaip 3 simbolių",

     default_pass: "Slaptažodis Reikalingas el",
     pass_max: "Slaptažodis turi susidaryti ne daugiau kaip iš 35 simbolių",

     group_name_required: "Reikalingas grupės pavadinimas",
     group_name_max_length: "Grupės pavadinimas turi susidaryti iš ne daugiau kaip 250 simbolių",
     group_name_min_length: "Grupės pavadinimas turi susidaryti iš ne mažiau kaip 1 simbolio",

     title_required: "Reikalingas pavadinimas",
     title_max_length: "Pavadinimas turi susidaryti iš ne daugiau kaip 250 simbolių",
     title_min_length: "Pavadinimas turi susidaryti iš ne mažiau kaip 1 simbolio",
 
     price_required: "Reikalinga nurodyti kainą",
     price_max_length: "Kaina turi susidaryti iš ne daugiau kaip 6 skaitmenų",
     price_min_length: "Kaina turi susidaryti iš ne mažiau kaip 1 skaitmens",
     only_number_allowed: "Galimi tik skaičiai",
 
     description_required: "Reikalingas aprašymas",
     description_max_length: "Aprašymas turi susidaryti iš ne daugiau kaip 500 simbolių",
     description_min_length: "Aprašymas turi susidaryti iš ne mažiau kaip 3 simbolių",


     lesson_title_required: "Reikalingas pamokos pavadinimas",
     lesson_title_max_length: "Pamokos pavadinimas turi susidaryti iš ne daugiau kaip 250 simbolių",
     lesson_title_min_length: "Pamokos pavadinimas turi susidaryti iš ne mažiau kaip 1 simbolio",
 
 
     sort_required: "Reikalingas rūšiavimas",
     sort_max_length: "Rūšiavimas turi susidaryti iš ne daugiau kaip 250 simbolių",
     sort_min_length: "Rūšiavimas turi susidaryti iš ne mažiau kaip 1 simbolio",
 
 
     question_required: "Reikalingas klausimas",
     question_max_length: "Klausimas turi susidaryti iš ne daugiau kaip 250 simbolių",
     question_min_length: "Klausimas turi susidaryti iš ne mažiau kaip 1 simbolio",

     answer_required: "Reikalingas atsakymas",
     answer_max_length: "Atsakymas turi susidaryti iš ne daugiau kaip 250 simbolių",
     answer_min_length: "Atsakymas turi susidaryti iš ne mažiau kaip 1 simbolio",
     
     option_required: "Reikalingas pasirinkimas",
     option_max_length: "Pasirinkimas turi susidaryti iš ne daugiau kaip  250 simbolių",
     option_min_length: "Pasirinkimas turi susidaryti iš ne mažiau kaip 1 simbolio",

     name_required: "Reikalingas vardas",
     name_max_length: "Vardas turi susidaryti iš ne daugiau kaip 250 simbolių",
     name_min_length: "Vardas turi susidaryti iš ne mažiau kaip 1 simbolio",
 
     points_required: "Reikalingi taškai",
     points_max_length: "Taškai turi susidaryti iš ne daugiau kaip 6 skaitmenų",
     points_min_length: "Taškai turi susidaryti iš ne mažiau kaip 1 skaitmens",
 
     from_range_required: "Reikalingas siuntėjas",
     from_range_max_length: "Siuntėjo vardas turi susidaryti iš ne daugiau kaip 6 simbolių",
     from_range_min_length: "Siuntėjo vardas turi susidaryti iš ne mažiau kaip 1 simbolio",
 
     to_range_required: "Reikalingas gavėjas",
     to_max_length: "Gavėjo vardas turi susidaryti iš ne daugiau kaip 6 simbolių",
     to_min_length: "Gavėjo vardas turi susidaryti iš ne mažiau kaip 1 simbolio",
 
     section_name_required: "Reikalingas skyriaus pavadinimas",
     section_name_max_length: "Skyriaus pavadinimas turi susidaryti iš ne daugiau kaip 250 simbolių",
     section_name_min_length: "Skyriaus pavadinimas turi susidaryti iš ne mažiau kaip 1 simbolio",

     sorting_position_required: "Reikalinga rūšiavimo tvarka",
     sorting_position_max_length: "Rūšiavimo tvarka turi būti sudaryta iš ne daugiau kaip 3 skaitmenų",
     sorting_position_min_length: "Rūšiavimo tvarka turi būti sudaryta iš ne mažiau kaip 1 skaitmens",

     product_required: "Reikalingas produkto pavadinimas",

     promo_code_required: "Reikalingas promo kodas",
     promo_code_max_length: "Promo kodas turi būti sudarytas iš ne daugiau kaip 50 skaitmenų",
     promo_code_min_length: "Promo kodas turi būti sudarytas iš ne mažiau kaip 3 skaitmenų",
 
     promo_name_required: "Reikalingas promo pavadinimas",
     promo_name_max_length: "Promo pavadinimas turi susidaryti iš ne daugiau kaip 250 simbolių",
     promo_name_min_length: "Promo pavadinimas turi susidaryti iš ne mažiau kaip 1 simbolio",
 
     promo_discount_required : "Reikalinga nuolaida",
     promo_discount_max_length: "Nuolaida turi būti sudaryta iš ne daugiau kaip 7 skaitmenų",
     promo_discount_max_length_four: "Nuolaida turi būti sudaryta iš ne daugiau kaip 4 skaitmenų",
     promo_discount_min_length: "Nuolaida turi būti sudaryta iš ne mažiau kaip 1 skaitmens",
 
     promo_users_per_coupon_required: "Reikalinga nurodyti vartotoją, kuriam priklauso promo kodas",
     promo_users_per_coupon_discount_max_length: "Vartotojo, kuriam priklauso nuolaidos kodas, vardas negali būti ilgesnis nei 5 simboliai",
     promo_users_per_coupon_discount_min_length: "Vartotojo, kuriam priklauso nuolaidos kodas, vardas negali būti trumoesnis nei 1 simbolis",

     delete_user: "Ar tikrai norite ištrinti šį vartotoją?",
     delete_admin: "Ar tikrai norite ištrinti šį administratorių?",
     delete_group: "Ar tikrai norite ištrinti šią grupę?",
     delete_product: "Ar tikrai norite ištrinti šį produktą?",
     delete_badge: "Ar tikrai norite ištrinti šį ženkliuką?",
     delete_section: "Ar tikrai norite ištrinti šią skiltį?",
     delete_product_order : "Ar tikrai norite ištrinti šį užsakymą?",
     delete_lesson: "Ar tikrai norite ištrinti šią pamoką?",
     delete_promo: "Ar tikrai norite ištrinti šį promo kodą?",

     no_records_found: "Įrašų nerasta",
     copy_right: "Visos teisės saugomos",

     profile: "profilis",
     logout: "Atsijungti",

     pass_string: "*Mažiausiai 8 simboliai * Būtini skaičiai * Būtini ypatingieji simboliai * Būtinos didžiosios raidės * Būtinos mažosios raidės",
     pass_default: "Slaptažodis būtinas, Mažiausiai 8 simboliai, Būtini skaičiai, Būtini ypatingieji simboliai, Būtinos didžiosios raidės, Būtinos mažosios raidės",
     pass_max: "Slaptažodis turi susidaryti iš 8 -35 simbolių",
     pass_min: "Slaptažodis turi susidaryti iš 8 -100 simbolių",
     
     loading: '“Kraunama”',
     no_purchased_items: "Įsigytų prekių nerasta",
     apple_in_app: "Apple",
 



    // buttons

    download_csv: "Atsisiųsti CSV",
    add_user: "Pridėti vartotoją",
    add_admin: "Pridėti administratorių",
    edit_admin: "Redaguoti administratorių",
    enabled: "Įjungtas",
    disabled: "Išjungtas",
    manage: "Redaguoti vartotojus",
    manage_group: "Redaguoti grupes",
    add_group: "Pridėti grupę",
    free_access: "Nemokama prieiga",
    add_product: "Pridėti produktą",
    add_badge: "Pridėti ženkliuką",
    add_section: "Pridėti sekciją",
    add_product_order: " Pridėti turinį",
    add_promo : 'Pridėti “Promo” kodą',
    edit_user: "Redaguoti Vartotoją",
    back: "Atgal",
    view_details: "Išsamiau",
    save: "Išsaugoti",
    update: "Atnaujinti",

    confirm: "Patvirtinti",
    cancel: "Atšaukti",
    ok: "Gerai",
    in_app_purchase: "Apple pirkimo transakcijos id",
    in_app_purchase_required: "Apple pirkimo transakcijos id yra būtinas",

    verification_code: "Patvirtinimo kodas",
    forgot_email_text: "Jei negaunate patvirtinimo kodo per ateinančias 5 minutes, susisiektite su administratoriumi",

}


export default function language(name){
    if(name  == "en"){
        return en
    }else{
        return lt
    }
}

