import * as React from "react"
import { Dialog } from "@reach/dialog"

export default class ConfirmStatusChange extends React.Component {
  state = {
    open             : false,
    callback         : null,
    confirmButtonText: this.props.confirmButtonText,
    cancleButtonText : this.props.cancleButtonText,
    cancleButtonStatus:this.props.cancleButtonStatus
  }

  show = callback => event => {
    if(event) {
      event.preventDefault()

      event = {
        ...event,
        target: { ...event.target, value: event.target.value }
      }
    }


    this.setState({
      open: true,
      callback: () => callback(event)
    })
  }

  cancel = () => {
    if(this.props.onCancel instanceof Function) {
      this.props.onCancel();
    }
    this.hide();
  }

  hide = () => this.setState({ open: false, callback: null })

  confirm = () => {
    this.state.callback()
    this.hide()
  }

  render() {
    return (
      <React.Fragment>
        {this.props.children(this.show)}
        {this.state.open && (
          <Dialog>
            <div className="modal-header">
              <h4 className="m-0">{this.props.title}</h4>
              <button type="button" className="btn btn-default fas fa-times text-white close-btn" onClick={()=>{this.cancel()}}></button>
            </div>
            <div className="modal-body text-center bg-white">
              <p>{this.props.description}</p>
              { this.state.cancleButtonStatus && <button className="btn btn-secondary btn-md btn-bordered ml-1 mr-1" onClick={this.cancel}>{this.state.cancleButtonText ? this.state.cancleButtonText : 'Cancel' }</button>}
              <button className="btn btn-primary btn-md btn-bordered ml-1 mr-1" onClick={this.confirm}>{this.state.confirmButtonText ? this.state.confirmButtonText : 'OK'}</button>
            </div>
          </Dialog>
        )}
      </React.Fragment>
    )
  }
}
